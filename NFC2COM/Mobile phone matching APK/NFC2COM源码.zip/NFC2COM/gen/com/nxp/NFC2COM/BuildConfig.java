/** Automatically generated file. DO NOT MODIFY */
package com.nxp.NFC2COM;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}