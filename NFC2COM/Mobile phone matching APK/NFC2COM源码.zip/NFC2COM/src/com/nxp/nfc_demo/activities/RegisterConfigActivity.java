package com.nxp.nfc_demo.activities;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.nfc.NfcAdapter;
import android.nfc.NfcAdapter.ReaderCallback;
import android.nfc.Tag;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

import com.nxp.NFC2COM.R;
import com.nxp.nfc_demo.exceptions.DemoNotSupportedException;
import com.nxp.nfc_demo.reader.Ntag_I2C_Demo;
import com.nxp.nfc_demo.reader.Ntag_I2C_Registers;

@SuppressLint("NewApi")
public class RegisterConfigActivity extends Activity implements
		OnClickListener, OnCheckedChangeListener {
	private PendingIntent pendingIntent;
	private NfcAdapter mAdapter;

	private static TextView ChipInfo_1_text;
	private static TextView ChipInfo_2_text;
	private static Switch I2C_RST_switch;
	private static Spinner FD_OFF_spinner;
	private static Spinner FD_ON_spinner;
	private static TextView LAST_NDEF_PAGE_edit;
	private static Switch PTHRU_DIR_switch;
	private static Switch WRITE_ACCESS_switch;
	private static TextView SRAM_MIRROR_PAGE_edit_edit;
	private static TextView I2C_WD_LS_Timer_edit;
	private static TextView I2C_WD_MS_edit;
	private static Switch I2C_CLOCK_STR_switch;

	private static Button readConfigButton;
	private static Button writeConfigButton;

	private LinearLayout layoutChipInfo;
	private RelativeLayout rlChipInfo;

	private LinearLayout layoutFD;
	private RelativeLayout rlFD;

	private LinearLayout layoutPT;
	private LinearLayout rlPT;

	private LinearLayout layoutMemory;
	private RelativeLayout rlMemory;

	private LinearLayout layoutI2C;
	private RelativeLayout rlI2C;

	private ImageView imageChipInfo;
	private ImageView imageFD;
	private ImageView imagePT;
	private ImageView imageSram;
	private ImageView imageI2C;

	private LinearLayout layout_read;
	private LinearLayout layout_buttons;
	private ScrollView scroll_regs;

	private boolean layoutChipInfoExpanded = false;
	private boolean layoutFDExpanded = false;
	private boolean layoutPTExpanded = false;
	private boolean layoutMemoryExpanded = false;
	private boolean layoutI2CExpanded = false;

	private static String option;
	private static boolean writeChosen;

	private static int NC_Reg = 0;
	private static int LD_Reg = 0;
	private static int SM_Reg = 0;
	private static int NS_Reg = 0;
	private static int WD_LS_Reg = 0;
	private static int WD_MS_Reg = 0;
	private static int I2C_CLOCK_STR = 0;

	private static int FD_OFF_Value = 0;
	private static int FD_ON_Value = 0;

	private Ntag_I2C_Demo demo;

	@SuppressLint("NewApi")
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_registerconfig);

		layout_read = (LinearLayout) findViewById(R.id.lconf);
		layout_buttons = (LinearLayout) findViewById(R.id.lconfbuttons);
		scroll_regs = (ScrollView) findViewById(R.id.sconf);

		ChipInfo_1_text = (TextView) findViewById(R.id.ChipProd_1_text);
		ChipInfo_2_text = (TextView) findViewById(R.id.ChipInfo_2_text);

		I2C_RST_switch = (Switch) findViewById(R.id.I2C_RST_STR);
		FD_OFF_spinner = (Spinner) findViewById(R.id.FD_OFF_Spinner);
		FD_ON_spinner = (Spinner) findViewById(R.id.FD_ON_Spinner);

		ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
				this, R.array.FD_OFF_Options,
				android.R.layout.simple_spinner_item);

		// Specify the layout to use when the list of choices appears
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

		// Apply the adapter to the spinner
		FD_OFF_spinner.setAdapter(adapter);

		adapter = ArrayAdapter.createFromResource(this, R.array.FD_ON_Options,
				android.R.layout.simple_spinner_item);
		// Specify the layout to use when the list of choices appears
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		FD_ON_spinner.setAdapter(adapter);

		LAST_NDEF_PAGE_edit = (TextView) findViewById(R.id.LAST_NDEF_PAGE_edit);
		// PTHRU_ON_OFF_switch = (Switch) findViewById(R.id.PTHRU_ON_OFF);
		PTHRU_DIR_switch = (Switch) findViewById(R.id.PTHRU_DIR);
		WRITE_ACCESS_switch = (Switch) findViewById(R.id.WRITE_ACCESS);

		PTHRU_DIR_switch.setOnCheckedChangeListener(this);
		WRITE_ACCESS_switch.setOnCheckedChangeListener(this);

		// SRAM_MIRROR_ON_OFF_switch = (Switch)
		// findViewById(R.id.SRAM_MIRROR_ON_OFF);
		SRAM_MIRROR_PAGE_edit_edit = (TextView) findViewById(R.id.SRAM_MIRROR_PAGE_edit);
		I2C_WD_LS_Timer_edit = (TextView) findViewById(R.id.I2C_WD_LS_edit);
		I2C_WD_MS_edit = (TextView) findViewById(R.id.I2C_WD_MS_edit);

		I2C_CLOCK_STR_switch = (Switch) findViewById(R.id.I2C_CLOCK_STR);

		readConfigButton = (Button) findViewById(R.id.readConfigButton);
		writeConfigButton = (Button) findViewById(R.id.writeConfigButton);

		readConfigButton.setOnClickListener(this);
		writeConfigButton.setOnClickListener(this);

		layoutChipInfo = (LinearLayout) findViewById(R.id.General_Chip_Information);
		rlChipInfo = (RelativeLayout) findViewById(R.id.General_Chip_Information_info);

		layoutFD = (LinearLayout) findViewById(R.id.Section_FD);
		rlFD = (RelativeLayout) findViewById(R.id.Section_FD_Info);

		layoutPT = (LinearLayout) findViewById(R.id.Section_PT);
		rlPT = (LinearLayout) findViewById(R.id.Section_PT_Info);

		layoutMemory = (LinearLayout) findViewById(R.id.Section_Memory);
		rlMemory = (RelativeLayout) findViewById(R.id.Section_Memory_info);

		layoutI2C = (LinearLayout) findViewById(R.id.Section_I2C_C);
		rlI2C = (RelativeLayout) findViewById(R.id.Section_I2C_C_Info);

		// Default Selection: Read
		writeChosen = false;

		layoutChipInfo.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (layoutChipInfoExpanded == true) {
					imageChipInfo.setImageResource(R.drawable.expand);
					rlChipInfo.setVisibility(View.GONE);
					layoutChipInfoExpanded = false;
				} else {
					imageChipInfo.setImageResource(R.drawable.hide);
					rlChipInfo.setVisibility(View.VISIBLE);
					layoutChipInfoExpanded = true;
				}
			}
		});

		layoutFD.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (layoutFDExpanded == true) {
					imageFD.setImageResource(R.drawable.expand);
					rlFD.setVisibility(View.GONE);
					layoutFDExpanded = false;
				} else {
					imageFD.setImageResource(R.drawable.hide);
					rlFD.setVisibility(View.VISIBLE);
					layoutFDExpanded = true;
				}
			}
		});

		layoutPT.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (layoutPTExpanded == true) {
					imagePT.setImageResource(R.drawable.expand);
					rlPT.setVisibility(View.GONE);
					layoutPTExpanded = false;
				} else {
					imagePT.setImageResource(R.drawable.hide);
					rlPT.setVisibility(View.VISIBLE);
					layoutPTExpanded = true;
				}
			}
		});

		layoutMemory.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (layoutMemoryExpanded == true) {
					imageSram.setImageResource(R.drawable.expand);
					rlMemory.setVisibility(View.GONE);
					layoutMemoryExpanded = false;
				} else {
					imageSram.setImageResource(R.drawable.hide);
					rlMemory.setVisibility(View.VISIBLE);
					layoutMemoryExpanded = true;
				}
			}
		});

		layoutI2C.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (layoutI2CExpanded == true) {
					imageI2C.setImageResource(R.drawable.expand);
					rlI2C.setVisibility(View.GONE);
					layoutI2CExpanded = false;
				} else {
					imageI2C.setImageResource(R.drawable.hide);
					rlI2C.setVisibility(View.VISIBLE);
					layoutI2CExpanded = true;
				}
			}
		});

		imageChipInfo = (ImageView) findViewById(R.id.imageGeneralChip);
		imageFD = (ImageView) findViewById(R.id.imageFD);
		imagePT = (ImageView) findViewById(R.id.imagePT);
		imageSram = (ImageView) findViewById(R.id.imageSramMirror);
		imageI2C = (ImageView) findViewById(R.id.imageI2C);

		// Add Foreground dispatcher
		mAdapter = NfcAdapter.getDefaultAdapter(this);
		pendingIntent = PendingIntent.getActivity(this, 0, new Intent(this,
				getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);
		return; // end onCreate

	}
	
	private ReaderCallback createReaderCallback(final Activity main) {
		return new ReaderCallback() {

			@Override
			public void onTagDiscovered(final Tag tag) {

				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						startDemo(tag);
					}
				});
			}
		};
	}

	@SuppressLint("NewApi")
	@Override
	public void onPause() {
		super.onPause();
		if (mAdapter != null) {
			if (Build.VERSION.SDK_INT >= 19)
				mAdapter.disableReaderMode(this);
			else
				mAdapter.disableForegroundDispatch(this);
		}
	}

	@Override
	public void onBackPressed() {
		Intent output = new Intent();
		setResult(RESULT_OK, output);
		finish();
	}

	@TargetApi(Build.VERSION_CODES.KITKAT)
	@Override
	public void onResume() {
		super.onResume();

		if (mAdapter != null) {
			Bundle options = new Bundle();
			options.putInt(NfcAdapter.EXTRA_READER_PRESENCE_CHECK_DELAY, 20);

			if (Build.VERSION.SDK_INT >= 19) {
				mAdapter.enableReaderMode(this, createReaderCallback(this),
						NfcAdapter.FLAG_READER_NFC_A, Bundle.EMPTY);
			} else {
				mAdapter.enableForegroundDispatch(this, pendingIntent, null,
						null);
			}
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.menu, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle presses on the action bar items
		switch (item.getItemId()) {
		case R.id.action_about:
			showAboutDialog();

			return true;

		default:
			return super.onOptionsItemSelected(item);
		}
	}

	@Override
	protected void onNewIntent(Intent nfc_intent) {
		// Make visible the registers scrollview

		final Tag tag = nfc_intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
		startDemo(tag);
	}

	private void startDemo(final Tag tag) {
		demo = new Ntag_I2C_Demo(tag, this);
		if (!demo.isReady())
			return;

		// Calculate the Register Values according to what has been selected by
		// the user
		calcConfiguration();

		try {
			demo.readWriteConfigRegister();
		} catch (DemoNotSupportedException e) {
			new AlertDialog.Builder(this)
					.setMessage(
							"This NFC device does not support the NFC Forum commands needed to access the config register")
					.setTitle("Command not supported")
					.setPositiveButton("OK",
							new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface dialog,
										int which) {

								}
							}).show();
			return;
		}

		layout_read.setVisibility(View.GONE);
		layout_buttons.setVisibility(View.VISIBLE);
		scroll_regs.setVisibility(View.VISIBLE);
	}

	@Override
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
		switch (buttonView.getId()) {
		case R.id.PTHRU_DIR:
			if (PTHRU_DIR_switch.isChecked()) {
				WRITE_ACCESS_switch.setChecked(true);
			} else {
				WRITE_ACCESS_switch.setChecked(false);
			}
			break;

		case R.id.WRITE_ACCESS:
			if (WRITE_ACCESS_switch.isChecked()) {
				PTHRU_DIR_switch.setChecked(true);
			} else {
				PTHRU_DIR_switch.setChecked(false);
			}
			break;
		}

	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.readConfigButton:
			readConfigButton.setBackgroundResource(R.drawable.btn_blue);
			writeConfigButton.setBackgroundColor(Color.BLACK);
			writeChosen = false;

			if (demo.isConnected())
				try {
					demo.readWriteConfigRegister();
				} catch (DemoNotSupportedException e) {
					// can never happen
					e.printStackTrace();
				}

			break;

		case R.id.writeConfigButton:
			if (writeChosen == true) {
				// Calculate the Register Values according to what has been
				// selected by the user
				calcConfiguration();

				if (demo.isConnected())
					try {
						demo.readWriteConfigRegister();
					} catch (DemoNotSupportedException e) {
						// can never happen
						e.printStackTrace();
					}
			} else {
				writeConfigButton.setBackgroundResource(R.drawable.btn_blue);
				readConfigButton.setBackgroundColor(Color.BLACK);
				writeChosen = true;
			}

			break;

		default:
			break;
		}
	} // END onClick (View v)

	public static String getOption() {
		return option;
	}

	public static void setAnswer(Ntag_I2C_Registers answer, Context cont) {
		ChipInfo_1_text.setText(answer.Manufacture);
		ChipInfo_2_text.setText(String.valueOf(answer.Mem_size) + " Bytes");

		// I2C_RST Switch
		I2C_RST_switch.setChecked(answer.I2C_RST_ON_OFF);

		if (answer.FD_OFF.equals(cont.getString(R.string.FD_OFF_ON_11)))
			FD_OFF_spinner.setSelection(3);
		if (answer.FD_OFF.equals(cont.getString(R.string.FD_OFF_ON_10)))
			FD_OFF_spinner.setSelection(2);
		if (answer.FD_OFF.equals(cont.getString(R.string.FD_OFF_ON_01)))
			FD_OFF_spinner.setSelection(1);
		if (answer.FD_OFF.equals(cont.getString(R.string.FD_OFF_ON_00)))
			FD_OFF_spinner.setSelection(0);

		if (answer.FD_ON.equals(cont.getString(R.string.FD_OFF_ON_11)))
			FD_ON_spinner.setSelection(3);
		if (answer.FD_ON.equals(cont.getString(R.string.FD_OFF_ON_10)))
			FD_ON_spinner.setSelection(2);
		if (answer.FD_ON.equals(cont.getString(R.string.FD_OFF_ON_01)))
			FD_ON_spinner.setSelection(1);
		if (answer.FD_ON.equals(cont.getString(R.string.FD_OFF_ON_00)))
			FD_ON_spinner.setSelection(0);

		// Get the Last NDEF Page
		LAST_NDEF_PAGE_edit.setText(String.valueOf(answer.LAST_NDEF_PAGE));

		// PassThrough ON_OFF
		// PTHRU_ON_OFF_switch.setChecked(answer.PTHRU_ON_OFF);

		// PassThrough Dir + Write Access
		if (answer.PTHRU_DIR) {
			PTHRU_DIR_switch.setChecked(true);
			WRITE_ACCESS_switch.setChecked(true);
		} else {
			PTHRU_DIR_switch.setChecked(false);
			WRITE_ACCESS_switch.setChecked(false);
		}

		SRAM_MIRROR_PAGE_edit_edit.setText(String.valueOf(answer.SM_Reg));
		I2C_WD_LS_Timer_edit.setText(String.valueOf(answer.WD_LS_Reg));
		I2C_WD_MS_edit.setText(String.valueOf(answer.WD_MS_Reg));

		// SRAM_MIRROR_ON_OFF_switch.setChecked(answer.SRAM_MIRROR_ON_OFF);
		I2C_CLOCK_STR_switch.setChecked(answer.I2C_CLOCK_STR);
	} // END set Answer

	public static void calcConfiguration() {
		FD_OFF_Value = FD_OFF_spinner.getSelectedItemPosition();
		FD_ON_Value = FD_ON_spinner.getSelectedItemPosition();

		// if (PTHRU_ON_OFF_switch.isChecked())
		// NC_Reg = (NC_Reg | (byte) 0x40);
		// else
		// NC_Reg = (NC_Reg & (byte) 0xbf);

		if (FD_OFF_Value == 3)
			NC_Reg = (NC_Reg | 0x30);

		if (FD_OFF_Value == 2) {
			NC_Reg = (NC_Reg & 0xcf);
			NC_Reg = (NC_Reg | 0x20);
		}

		if (FD_OFF_Value == 1) {
			NC_Reg = (NC_Reg & 0xcf);
			NC_Reg = (NC_Reg | 0x10);
		}

		if (FD_OFF_Value == 0)
			NC_Reg = (NC_Reg & 0xcf);

		if (FD_ON_Value == 3)
			NC_Reg = (NC_Reg | 0x0c);

		if (FD_ON_Value == 2) {
			NC_Reg = (NC_Reg & 0xf3);
			NC_Reg = (NC_Reg | 0x08);
		}

		if (FD_ON_Value == 1) {
			NC_Reg = (NC_Reg & 0xf3);
			NC_Reg = (NC_Reg | 0x04);
		}

		if (FD_ON_Value == 0) {
			NC_Reg = (NC_Reg & 0xf3);
		}

		// if (SRAM_MIRROR_ON_OFF_switch.isChecked())
		// NC_Reg = (NC_Reg | (byte) 0x02);
		// else
		// NC_Reg = (NC_Reg & (byte) 0xfd);

		if (PTHRU_DIR_switch.isChecked())
			NC_Reg = (NC_Reg | (byte) 0x01);
		else
			NC_Reg = (NC_Reg & (byte) 0xfe);

		LD_Reg = Integer.parseInt(LAST_NDEF_PAGE_edit.getText().toString());
		SM_Reg = Integer.parseInt(SRAM_MIRROR_PAGE_edit_edit.getText()
				.toString());
		WD_LS_Reg = Integer.parseInt(I2C_WD_LS_Timer_edit.getText().toString());
		WD_MS_Reg = Integer.parseInt(I2C_WD_MS_edit.getText().toString());

		if (I2C_CLOCK_STR_switch.isChecked())
			I2C_CLOCK_STR = 1;
		else
			I2C_CLOCK_STR = 0;

		if (I2C_RST_switch.isChecked())
			NC_Reg = (NC_Reg | (byte) 0x80);
		else
			NC_Reg = (NC_Reg & (byte) 0x7f);

		return;
	}

	public static boolean isWriteChosen() {
		return writeChosen;
	}

	// return registers
	public static int getNC_Reg() {
		return NC_Reg;
	}

	public static int getLD_Reg() {
		return LD_Reg;
	}

	public static int getSM_Reg() {
		return SM_Reg;
	}

	public static int getNS_Reg() {
		return NS_Reg;
	}

	public static int getWD_LS_Reg() {
		return WD_LS_Reg;
	}

	public static int getWD_MS_Reg() {
		return WD_MS_Reg;
	}

	public static int getI2C_CLOCK_STR() {
		return I2C_CLOCK_STR;
	}

	// set registers
	public static void setNC_Reg(int nC_Reg2) {
		NC_Reg = nC_Reg2;
	}

	public static void setLD_Reg(int lD_Reg2) {
		LD_Reg = lD_Reg2;
	}

	public static void setSM_Reg(int sM_Reg2) {
		SM_Reg = sM_Reg2;
	}

	public static void setNS_Reg(int nS_Reg2) {
		NS_Reg = nS_Reg2;
	}

	public static void setWD_LS_Reg(int wD_LS_Reg2) {
		WD_LS_Reg = wD_LS_Reg2;
	}

	public static void setWD_MS_Reg(int wD_MS_Reg2) {
		WD_MS_Reg = wD_MS_Reg2;
	}

	public static void setI2C_CLOCK_STR(int i2C_CLOCK_STR) {
		I2C_CLOCK_STR = i2C_CLOCK_STR;
	}

	public void showAboutDialog() {
		Intent intent = null;
		intent = new Intent(this, VersionInfoActivity.class);
		startActivity(intent);
	}
}
