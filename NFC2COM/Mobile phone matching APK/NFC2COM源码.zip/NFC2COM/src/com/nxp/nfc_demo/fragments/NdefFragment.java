package com.nxp.nfc_demo.fragments;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings.Secure;
import android.support.v4.app.Fragment;
import android.telephony.TelephonyManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.TextView;

import com.nxp.NFC2COM.R;
import com.nxp.nfc_demo.activities.MainActivity;

public class NdefFragment extends Fragment implements OnClickListener,
		OnCheckedChangeListener {
	private static RadioGroup ndefWriteOptions;
	private static LinearLayout ndefReadType;

	private static TextView ndefText;
	private static EditText ndefEditText;

	private LinearLayout linearBt;
	private static EditText ndefEditMac;
	private static EditText ndefEditName;
	private static EditText ndefEditClass;

	private static TextView ndefTypeText;
	private static TextView ndefCallback;

	private Button readNdefButton;
	private Button writeNdefButton;
	private Button writeDefaultNdefButton;

	private static boolean writeChosen = false;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setRetainInstance(true);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View layout = inflater
				.inflate(R.layout.fragment_ndef, container, false);

		ndefText = (TextView) layout.findViewById(R.id.ndefText);
		ndefEditText = (EditText) layout.findViewById(R.id.ndefEditText);
		ndefEditText.setText(getVaule());

		linearBt = (LinearLayout) layout.findViewById(R.id.layoutBt);
		ndefEditMac = (EditText) layout.findViewById(R.id.ndefEditMac);
		ndefEditName = (EditText) layout.findViewById(R.id.ndefEditName);
		ndefEditClass = (EditText) layout.findViewById(R.id.ndefEditClass);

		ndefTypeText = (TextView) layout.findViewById(R.id.ndefTypeText);
		ndefCallback = (TextView) layout.findViewById(R.id.ndef_textCallback);

		ndefWriteOptions = (RadioGroup) layout.findViewById(R.id.ndefOptions);
		ndefReadType = (LinearLayout) layout.findViewById(R.id.ndefTypeLayout);

		readNdefButton = (Button) layout.findViewById(R.id.readNdefButton);
		writeNdefButton = (Button) layout.findViewById(R.id.writeNdefButton);
		writeDefaultNdefButton = (Button) layout
				.findViewById(R.id.writeDefaultButton);

		readNdefButton.setOnClickListener(this);
		writeNdefButton.setOnClickListener(this);
		writeDefaultNdefButton.setOnClickListener(this);

		ndefWriteOptions.setOnCheckedChangeListener(this);

		// Set the variable to false to avoid sending the last selected value
		writeChosen = true;

		return layout;
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.readNdefButton:
			ndefCallback
					.setText(getResources().getString(R.string.readNdefMsg));

			readNdefButton.setBackgroundResource(R.drawable.btn_blue);
			writeNdefButton.setBackgroundColor(Color.BLACK);
			ndefWriteOptions.setVisibility(View.GONE);
			ndefReadType.setVisibility(View.VISIBLE);
			linearBt.setVisibility(View.GONE);
			ndefEditText.setVisibility(View.GONE);
			ndefText.setVisibility(View.VISIBLE);

			writeChosen = false;

			// Read content
			MainActivity.launchNdefDemo();

			break;

		case R.id.writeNdefButton:
			if (writeChosen == true)
				MainActivity.launchNdefDemo();
			else {
				ndefCallback.setText(getResources().getString(
						R.string.writeNdefMsg));

				writeNdefButton.setBackgroundResource(R.drawable.btn_blue);
				readNdefButton.setBackgroundColor(Color.BLACK);
				ndefWriteOptions.setVisibility(View.VISIBLE);
				ndefReadType.setVisibility(View.GONE);

				if (getNdefType().equals(
						getResources().getString(R.string.radio_btpair))) {
					linearBt.setVisibility(View.VISIBLE);
					ndefEditText.setVisibility(View.GONE);
				} else {
					linearBt.setVisibility(View.GONE);
					ndefEditText.setVisibility(View.VISIBLE);
				}

				ndefText.setVisibility(View.GONE);

				writeChosen = true;
			}

			break;

		case R.id.writeDefaultButton:
			ndefCallback.setText(getResources()
					.getString(R.string.writeNdefMsg));

			writeNdefButton.setBackgroundResource(R.drawable.btn_blue);
			readNdefButton.setBackgroundColor(Color.BLACK);
			ndefWriteOptions.setVisibility(View.VISIBLE);
			ndefReadType.setVisibility(View.GONE);

			RadioButton bt = (RadioButton) ndefWriteOptions.getChildAt(0);
			bt.setChecked(true);

			linearBt.setVisibility(View.GONE);
			ndefEditText.setVisibility(View.VISIBLE);
			ndefEditText.setText(getResources()
					.getString(R.string.ndef_default));

			ndefText.setVisibility(View.GONE);

			writeChosen = true;

			// Write content
			MainActivity.launchNdefDemo();

			break;

		default:
			break;
		}
	} // END onClick (View v)

	@Override
	public void onCheckedChanged(RadioGroup group, int checkedId) {
		if (checkedId == R.id.radioNdefText) {
			ndefEditText.setVisibility(View.VISIBLE);
			ndefEditText.setText("");

			linearBt.setVisibility(View.GONE);
		} else if (checkedId == R.id.radioNdefUrl) {
			ndefEditText.setVisibility(View.VISIBLE);
			ndefEditText.setText("http://www.");

			linearBt.setVisibility(View.GONE);
		} else if (checkedId == R.id.radioNdefBt) {
			ndefEditText.setVisibility(View.GONE);
			linearBt.setVisibility(View.VISIBLE);
		}
	}

	public static String getText() {
		return ndefEditText.getText().toString();
	}

	public static String getBtMac() {
		return ndefEditMac.getText().toString();
	}

	public static String getBtName() {
		return ndefEditName.getText().toString();
	}

	public static String getBtClass() {
		return ndefEditClass.getText().toString();
	}

	public static void setAnswer(String answer) {
		ndefCallback.setText(answer);
	}

	public static void setNdefType(String type) {
		ndefTypeText.setText(type);
	}

	public static void setNdefMessage(String answer) {
		ndefText.setText(answer);
	}

	public static String getNdefType() {
		int id = ndefWriteOptions.getCheckedRadioButtonId();
		View radioButton = ndefWriteOptions.findViewById(id);
		int radioId = ndefWriteOptions.indexOfChild(radioButton);
		RadioButton btn = (RadioButton) ndefWriteOptions.getChildAt(radioId);
		return (String) btn.getText();
	}

	public static boolean isWriteChosen() {
		return writeChosen;
	}

	private String getVaule() {
		TelephonyManager telManager = (TelephonyManager) getActivity()
				.getSystemService(Context.TELEPHONY_SERVICE);
		String operator = telManager.getSimSerialNumber();// telManager.getSimOperator();
															// //
		if (operator != null) {
			if (!operator.isEmpty()) {
				operator = format(operator);
			} else // 如果取不到卡的串口
			{

				operator = telManager.getDeviceId(); // 如果取不到SIM卡串号，退而求其次，取手机的IMEI码，也就是*#06#获取的
				// 这个是一般的手机都能取得到
				if (operator != null) {
					if (!operator.isEmpty()) {
						operator = format(operator);
					}

				} else// 如果是平板电脑 ，没有MIME
				{
					String android_id = Secure.getString(getActivity()
							.getContentResolver(), Secure.ANDROID_ID);
					operator = format(operator);
				}
			}
		} else {
			operator = telManager.getDeviceId(); // 如果取不到SIM卡串号，退而求其次，取手机的IMEI码，也就是*#06#获取的
			// 这个是一般的手机都能取得到
			if (operator != null) {
				if (!operator.isEmpty()) {
					;
				}

			} else// 如果是平板电脑 ，没有MIME 获取设备ANDROID_ID
			{
				operator = Secure.getString(getActivity().getContentResolver(),
						Secure.ANDROID_ID);
			}

		}
		return operator;
	}

	private String format(String data) {
		char[] charArr = data.toCharArray();
		int[] intArr = new int[charArr.length];
		for (int i = 0; i < charArr.length; i++) {
			intArr[i] = charArr[i];
		}

		for (int i = 0; i < intArr.length; i++) {
			if (47 < intArr[i] && intArr[i] < 58) {
				intArr[i] = intArr[i] - 48;
			} else if (64 < intArr[i] && intArr[i] < 71) {
				intArr[i] = intArr[i] - 65 + 10 - 8;
			} else if (96 < intArr[i] && intArr[i] < 103) {
				intArr[i] = intArr[i] - 97 + 10 - 6;
			}
		}

		StringBuffer outString = new StringBuffer();
		for (int i = 0; i < intArr.length; i++) {
			outString.append(intArr[i]);
		}

		String temp = outString.toString();
		temp = temp.substring(temp.length() - 10, temp.length());
		return temp;
	}

}
