package com.nxp.nfc_demo.activities;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.NfcAdapter.ReaderCallback;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.nxp.NFC2COM.R;
import com.nxp.nfc_demo.reader.Ntag_I2C_Demo;

@SuppressLint("NewApi")
public class ResetMemoryActivity extends Activity {
	private PendingIntent pendingIntent;
	private NfcAdapter mAdapter;
	public static Context mContext;
	
	public Ntag_I2C_Demo demo;
	
	ProgressDialog dialog;
	
	private ReaderCallback createReaderCallback(final Activity main) {
		return new ReaderCallback() {

			@Override
			public void onTagDiscovered(final Tag tag) {

				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						startDemo(tag);
					}
				});
			}
		};
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_resetmemory);
		
		// Get the context reference
		mContext = getApplicationContext();

		// Add Foreground dispatcher
		mAdapter = NfcAdapter.getDefaultAdapter(this);
		pendingIntent = PendingIntent.getActivity(this, 0, new Intent(this, getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);
		
		return; // end onCreate
	}

	@SuppressLint("NewApi")
	@Override
	public void onPause() {
		super.onPause();
		if (mAdapter != null) {
			if (Build.VERSION.SDK_INT >= 19)
				mAdapter.disableReaderMode(this);
			else
				mAdapter.disableForegroundDispatch(this);
		}
	}

	@TargetApi(Build.VERSION_CODES.KITKAT)
	@Override
	public void onResume() {
		super.onResume();

		if (mAdapter != null) {
			Bundle options = new Bundle();
			options.putInt(NfcAdapter.EXTRA_READER_PRESENCE_CHECK_DELAY, 20);

			if (Build.VERSION.SDK_INT >= 19) {
				mAdapter.enableReaderMode(this, createReaderCallback(this),
						NfcAdapter.FLAG_READER_NFC_A, Bundle.EMPTY);
			} else {
				mAdapter.enableForegroundDispatch(this, pendingIntent, null,
						null);
			}
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.menu, menu);
		return true;
	}

	@Override
    public boolean onOptionsItemSelected(MenuItem item) { 
        // Handle presses on the action bar items
        switch (item.getItemId()) {
	        case R.id.action_about:
	        	showAboutDialog();
	        
	            return true;
                        
            default:
                return super.onOptionsItemSelected(item);
        }
    }
	
	@Override
	protected void onNewIntent(Intent nfc_intent) {		
		// Complete the task in a new thread in order to be able to show the dialog
		Tag tag = nfc_intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);		
		startDemo(tag);
	}

	private void startDemo(Tag tag) {
		demo = new Ntag_I2C_Demo(tag, this);
		if(!demo.isReady())
			return;
		
		// Launch the thread
		new resetTask().execute();
	}
	
	private class resetTask extends AsyncTask<Intent, Integer, Boolean> {
        @Override
		protected void onPostExecute(Boolean success) {  
        	// Inform the user about the task completion
        	contentReseted(success);
        	
    		// Action completed
    		dialog.dismiss();
        }

		@Override
		protected Boolean doInBackground(Intent... nfc_intent) {    
			// Reset the tag content
        	boolean successWrite = demo.resetTag();  
        	
        	return successWrite;
		}
		
		@Override
		protected void onPreExecute() {
			// Show the progress dialog on the screen to inform about the action
			dialog = ProgressDialog.show(ResetMemoryActivity.this, "Formatting", "Reseting memory content ...", true, true);
		}
    }
	
	public void contentReseted(boolean success) {
		if(success == true)
			Toast.makeText(mContext, "Reset Completed", Toast.LENGTH_SHORT).show();
		else
			Toast.makeText(mContext, "Error during memory content reset", Toast.LENGTH_SHORT).show();
	}
	
	public void showAboutDialog() {
		Intent intent = null;
		intent= new Intent(this, VersionInfoActivity.class);		
		startActivity(intent);
	}
}
