package com.nxp.nfc_demo.activities;


import java.io.IOException;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.DialogInterface;
import android.content.Intent;
import android.nfc.FormatException;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.nxp.NFC2COM.R;
import com.nxp.nfc_demo.exceptions.DemoNotSupportedException;
import com.nxp.nfc_demo.reader.Ntag_I2C_Demo;

public class VersionInfoActivity extends Activity {
	private PendingIntent pendingIntent;
	private NfcAdapter mAdapter;

	private static TextView Board_Version_text;
	private static TextView Board_FW_Version_text;
	
	private LinearLayout Version_Information;
	private RelativeLayout Version_Information_info;

	
	private ImageView imageVersion;
	
	private LinearLayout layout_read;
	private ScrollView sconf_ver;
	
	private boolean VersionInfoExpanded = false;

	
	private Ntag_I2C_Demo demo;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_versioninfo);
		
		layout_read = (LinearLayout) findViewById(R.id.lconf_ver);
		sconf_ver = (ScrollView) findViewById(R.id.sconf_ver);

		Board_Version_text = (TextView) findViewById(R.id.Board_Version_text);
		Board_FW_Version_text = (TextView) findViewById(R.id.Board_FW_Version_text);
		
		Version_Information = (LinearLayout) findViewById(R.id.Version_Information);
		Version_Information_info = (RelativeLayout) findViewById(R.id.Version_Information_info);
		//Text = (RelativeLayout) findViewById(R.id.Version_Information_info);

		//DateUtils.getDate("yyyy/MM/dd hh:mm:ss.SSS",
        //        DateUtils.getBuildDate(this));

		
		Version_Information.setOnClickListener(new OnClickListener() {		
			@Override
			public void onClick(View v) {
				if (VersionInfoExpanded == true) {
					imageVersion.setImageResource(R.drawable.expand);
					Version_Information_info.setVisibility(View.GONE);
					VersionInfoExpanded = false;
				} else {
					imageVersion.setImageResource(R.drawable.hide);
					Version_Information_info.setVisibility(View.VISIBLE);
					VersionInfoExpanded = true;
				}
			}
		});
				
		
		imageVersion = (ImageView) findViewById(R.id.imageVersion);

		// Add Foreground dispatcher
		mAdapter = NfcAdapter.getDefaultAdapter(this);
		pendingIntent = PendingIntent.getActivity(this, 0, new Intent(this, getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);
		return; // end onCreate

	}

	@Override
	public void onPause() {
		super.onPause();
		if (mAdapter != null)
			mAdapter.disableForegroundDispatch(this);
	}

	@Override
	public void onBackPressed() {
		Intent output = new Intent();
		setResult(RESULT_OK, output);
		finish();
	}

	@Override
	public void onResume() {
		super.onResume();
		if (mAdapter != null)
			mAdapter.enableForegroundDispatch(this, pendingIntent, null, null);
	}

	@Override
	protected void onNewIntent(Intent nfc_intent) {
		
		final Tag tag = nfc_intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
		demo = new Ntag_I2C_Demo(tag, this);
		if(!demo.isReady())
			return;
		
		try {
			demo.getBoardVersion();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DemoNotSupportedException e)
		{
			new AlertDialog.Builder(this)
			.setMessage(
					"VersionInfo not supported")
			.setTitle("Tag not supported")
			.setPositiveButton("OK",
					new DialogInterface.OnClickListener() {
						@Override
						public void onClick(
								DialogInterface dialog,
								int which) {

						}
					}).show();
			return;
		}
		
		// Make visible the registers scrollview
		layout_read.setVisibility(View.GONE);
		sconf_ver.setVisibility(View.VISIBLE);
	}
	
	public static void setBoardVersion(String version)
	{
		Board_Version_text.setText(version);
	}
	
	public static void setBoardFWVersion(String version)
	{
		Board_FW_Version_text.setText(version);
	}
}
