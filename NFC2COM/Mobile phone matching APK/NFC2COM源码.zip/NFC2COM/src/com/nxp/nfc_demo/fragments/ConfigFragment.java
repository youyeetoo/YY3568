package com.nxp.nfc_demo.fragments;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.nxp.NFC2COM.R;
import com.nxp.nfc_demo.activities.ReadMemoryActivity;
import com.nxp.nfc_demo.activities.RegisterConfigActivity;
import com.nxp.nfc_demo.activities.RegisterSessionActivity;
import com.nxp.nfc_demo.activities.ResetMemoryActivity;

public class ConfigFragment extends Fragment implements OnClickListener {
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View v = inflater.inflate(R.layout.fragment_config, container, false);
		
		((ImageView) v.findViewById(R.id.configSessionRegister)).setOnClickListener(this);
		((ImageView) v.findViewById(R.id.configConfigRegister)).setOnClickListener(this);
		((ImageView) v.findViewById(R.id.readMemory)).setOnClickListener(this);
		((ImageView) v.findViewById(R.id.resetMemory)).setOnClickListener(this);
		
		return v;
	}

	@Override
	public void onClick(View v) {
		Intent intent = null;
		
		switch(v.getId()) {
			case R.id.readMemory:
				intent= new Intent(getActivity(), ReadMemoryActivity.class);			
				break;
				
			case R.id.resetMemory:
				intent  = new Intent(getActivity(), ResetMemoryActivity.class);
				break;
		
			case R.id.configSessionRegister:
				intent  = new Intent(getActivity(), RegisterSessionActivity.class);
				break;
				
			case R.id.configConfigRegister:
				intent = new Intent(getActivity(), RegisterConfigActivity.class);
				break;
		}
		
		startActivity(intent);
	}
}
