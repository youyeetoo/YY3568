package com.nxp.nfc_demo.fragments;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import com.nxp.NFC2COM.R;

public class LedFragment extends Fragment implements OnClickListener {

	private ImageView ntagLogo;

	static private Button Button1_check;
	static private Button Button2_check;
	static private Button Button3_check;
	static private CheckBox Scroll_check;
	
	private Animation anim;
	
	private static TextView textCallback;

	private static String option;
	
	private static double voltage;
	private static double temperatureC;
	private static double temperatureF;
	
	private static boolean chosen = false;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		anim = AnimationUtils.loadAnimation(getActivity(), R.anim.ntag);
		
		// Set the variable to false to avoid sending the last selected value
		chosen = false;
		
		// We set the LED information to 0 until the tag is tapped
		option = "L1";
		voltage = 0;
		temperatureC = 0;
		temperatureF = 0;
		
		setRetainInstance(true);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View layout = inflater.inflate(R.layout.fragment_leddemo, container, false);

		Button1_check = (Button) layout.findViewById(R.id.Button1_check);
		Button2_check = (Button) layout.findViewById(R.id.Button2_check);
		Button3_check = (Button) layout.findViewById(R.id.Button3_check);
		Scroll_check = (CheckBox) layout.findViewById(R.id.Ndef_Scroll_checkbox);

		((Button) layout.findViewById(R.id.redButton)).setOnClickListener(this);
		((Button) layout.findViewById(R.id.blueButton)).setOnClickListener(this);
		((Button) layout.findViewById(R.id.greenButton)).setOnClickListener(this);

		ntagLogo = (ImageView) layout.findViewById(R.id.trafficlight);

		textCallback = (TextView) layout.findViewById(R.id.textCallback);	
		
		if(option.equals("L1")) {
			ntagLogo.setImageResource(R.drawable.ntagred);
			ntagLogo.startAnimation(anim);
			
			option = "L1";
		} else if(option.equals("L2")) {
			ntagLogo.setImageResource(R.drawable.ntagblue);
			ntagLogo.startAnimation(anim);
			
			option = "L2";
		} else if(option.equals("L3")) {
			ntagLogo.setImageResource(R.drawable.ntaggreen);
			ntagLogo.startAnimation(anim);
			
			option = "L3";
		}
				
		return layout;
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.redButton:
			ntagLogo.setImageResource(R.drawable.ntagred);
			ntagLogo.startAnimation(anim);
			
			option = "L1";
			
			break;

		case R.id.blueButton:
			ntagLogo.setImageResource(R.drawable.ntagblue);
			ntagLogo.startAnimation(anim);
			
			option = "L2";
			
			break;

		case R.id.greenButton:
			ntagLogo.setImageResource(R.drawable.ntaggreen);
			ntagLogo.startAnimation(anim);
			
			option = "L3";
			
			break;

		default:
			break;
		}

		chosen = true;
		// textSelectColor.setText(R.string.tap);
	}

	public static void setButton(byte Bit_filed) {
		if ((Bit_filed & 0x01) == 0x01) {
			Button1_check.setEnabled(true);
		} else {
			Button1_check.setEnabled(false);
		}

		if ((Bit_filed & 0x02) == 0x02) {
			Button2_check.setEnabled(true);
		} else {
			Button2_check.setEnabled(false);
		}

		if ((Bit_filed & 0x04) == 0x04) {
			Button3_check.setEnabled(true);
		} else {
			Button3_check.setEnabled(false);
		}

	}
	
	public static boolean getChosen() {
		return chosen;
	}

	public static String getOption() {
		return option;
	}
	
	public static double getVoltage() {
		return voltage;
	}
	
	public static double getTemperatureC() {
		return temperatureC;
	}
	
	public static double getTemperatureF() {
		return temperatureF;
	}
	
	public static boolean getScrolling() {
		return Scroll_check.isChecked();
	}

	public static void setAnswer(String answer) {
		textCallback.setText(answer);
	}
	
	public static void setVoltage(double v) {
		voltage = v;
	}
	
	public static void setTemperatureC(double t) {
		temperatureC = t;
	}
	
	public static void setTemperatureF(double t) {
		temperatureF = t;
	}
}
